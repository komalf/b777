import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bethistorymobile',
  templateUrl: './bethistorymobile.component.html',
  styleUrls: ['./bethistorymobile.component.css']
})
export class BethistorymobileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
