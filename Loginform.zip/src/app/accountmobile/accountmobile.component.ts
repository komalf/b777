import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountmobile',
  templateUrl: './accountmobile.component.html',
  styleUrls: ['./accountmobile.component.css']
})
export class AccountmobileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
