import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sixpoker',
  templateUrl: './sixpoker.component.html',
  styleUrls: ['./sixpoker.component.css']
})
export class SixpokerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
