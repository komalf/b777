import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setbuttonmobile',
  templateUrl: './setbuttonmobile.component.html',
  styleUrls: ['./setbuttonmobile.component.css']
})
export class SetbuttonmobileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
