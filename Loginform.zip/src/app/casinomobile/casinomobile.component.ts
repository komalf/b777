import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-casinomobile',
  templateUrl: './casinomobile.component.html',
  styleUrls: ['./casinomobile.component.css']
})
export class CasinomobileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
