import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../api.service';


@Component({
  selector: 'app-passwordmobile',
  templateUrl: './passwordmobile.component.html',
  styleUrls: ['./passwordmobile.component.css']
})
export class PasswordmobileComponent implements OnInit {
  serviceVar: any;
  changePasswordForm: { value: any; };
  
  constructor(private formBuilder: FormBuilder, private apiService: ApiService,) { }

  ngOnInit() {
  }
  changePassword() {
    this.apiService.changePassword(this.changePasswordForm.value)
      .subscribe(res => console.log(res));
  }

}
