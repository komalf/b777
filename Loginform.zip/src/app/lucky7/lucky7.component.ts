import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lucky7',
  templateUrl: './lucky7.component.html',
  styleUrls: ['./lucky7.component.css']
})
export class Lucky7Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
