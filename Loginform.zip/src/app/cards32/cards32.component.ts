import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cards32',
  templateUrl: './cards32.component.html',
  styleUrls: ['./cards32.component.css']
})
export class Cards32Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
