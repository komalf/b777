import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-twentyteeenpatti',
  templateUrl: './twentyteeenpatti.component.html',
  styleUrls: ['./twentyteeenpatti.component.css']
})
export class TwentyteeenpattiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
