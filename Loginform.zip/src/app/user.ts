export interface User {
    username: string;
    pwd: string;
}
