import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unsetteledmobile',
  templateUrl: './unsetteledmobile.component.html',
  styleUrls: ['./unsetteledmobile.component.css']
})
export class UnsetteledmobileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
