import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dragon',
  templateUrl: './dragon.component.html',
  styleUrls: ['./dragon.component.css']
})
export class DragonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
