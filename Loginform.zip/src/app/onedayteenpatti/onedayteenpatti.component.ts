import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onedayteenpatti',
  templateUrl: './onedayteenpatti.component.html',
  styleUrls: ['./onedayteenpatti.component.css']
})
export class OnedayteenpattiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
