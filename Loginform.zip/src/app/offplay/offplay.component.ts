import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offplay',
  templateUrl: './offplay.component.html',
  styleUrls: ['./offplay.component.css']
})
export class OffplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
