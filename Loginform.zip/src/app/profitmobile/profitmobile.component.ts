import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profitmobile',
  templateUrl: './profitmobile.component.html',
  styleUrls: ['./profitmobile.component.css']
})
export class ProfitmobileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
