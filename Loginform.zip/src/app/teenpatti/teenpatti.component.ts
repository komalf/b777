import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teenpatti',
  templateUrl: './teenpatti.component.html',
  styleUrls: ['./teenpatti.component.css']
})
export class TeenpattiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
