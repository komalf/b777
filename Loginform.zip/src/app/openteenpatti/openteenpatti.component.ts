import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-openteenpatti',
  templateUrl: './openteenpatti.component.html',
  styleUrls: ['./openteenpatti.component.css']
})
export class OpenteenpattiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
