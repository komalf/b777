import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-twentypoker',
  templateUrl: './twentypoker.component.html',
  styleUrls: ['./twentypoker.component.css']
})
export class TwentypokerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
